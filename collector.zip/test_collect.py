import json
import copy
import gzip
import io
import tempfile
import unittest
from unittest.mock import patch
from datetime import datetime, timedelta, timezone
from pathlib import Path

from collect import Ledger, PublicReader, circlek_quote_is_current, circlek_up_url, import_circlek, costco_batch_url, import_costco_current, kwik_grade, literal, mills, pilot_location, utc


class CollectorChecks(unittest.TestCase):
    def setUp(self):
        workspace = Path(__file__).resolve().parent/".test-work"
        workspace.mkdir(exist_ok=True)
        self.directory = tempfile.TemporaryDirectory(dir=workspace)
        assert Path(self.directory.name).resolve().is_relative_to(workspace.resolve())
        self.addCleanup(self.directory.cleanup)
        self.now = datetime(2026, 10, 26, 16, tzinfo=timezone.utc)
        self.ledger = Ledger(Path(self.directory.name)/"history.json", self.now)
        self.station = {"id":"pilot:1", "name":"Independent Travel Center", "address":"100 Main St", "city":"Town", "state":"WI", "postcode":"54301", "lat":44.5, "lon":-88.0, "timezone":"America/Chicago", "source":"Retailer posted prices", "source_url":"https://pilotcompany.com/locations/1"}

    def add(self, amount, days=0, **changes):
        at = self.now-timedelta(days=days)
        old = self.ledger.now
        self.ledger.now = at
        try:
            self.ledger.observe(self.station | changes.pop("station", {}), changes.pop("product", "UL:1"), changes.pop("grade", "REGULAR_UNLEADED"), changes.pop("basis", "posted_unspecified"), amount, at)
        finally:
            self.ledger.now = old

    def test_independent_station_has_automatic_day_and_week_evidence(self):
        self.add(4.099, 7); self.add(4.299, 1); self.add(4.199)
        quote = self.ledger.feed()["stations"][0]["quotes"][0]
        self.assertEqual(quote["current"]["price_mills"], 4199)
        self.assertEqual(quote["day"]["price_mills"], 4299)
        self.assertEqual(quote["week"]["price_mills"], 4099)

    def test_missing_yesterday_does_not_substitute_another_day(self):
        self.add(4.099, 2); self.add(4.199)
        self.assertNotIn("day", self.ledger.feed()["stations"][0]["quotes"][0])

    def test_source_product_and_basis_never_mix(self):
        self.add(4.099, 1, product="E15:2"); self.add(4.199, 1, basis="cash"); self.add(4.299)
        quote = self.ledger.feed()["stations"][0]["quotes"][0]
        self.assertNotIn("day", quote)

    def test_multiple_current_blends_hide_the_grade(self):
        self.add(4.199); self.add(4.099, product="different-blend")
        self.assertEqual(self.ledger.feed()["stations"], [])

    def test_state_survives_process_restart(self):
        self.add(4.199, 1); self.add(4.099)
        self.ledger.save()
        loaded = Ledger(self.ledger.path, self.now)
        self.assertEqual(loaded.feed(), self.ledger.feed())

    def test_retention_keeps_week_and_discards_older_data(self):
        self.add(4.199, 30); self.add(4.199, 7); self.add(4.099)
        self.ledger.save()
        self.assertEqual(len(next(iter(self.ledger.days.values()))), 2)

    def test_today_in_station_timezone_not_utc(self):
        self.ledger.now = datetime(2026, 10, 27, 1, tzinfo=timezone.utc)
        at = self.ledger.now
        self.ledger.observe(self.station, "UL:1", "REGULAR_UNLEADED", "posted_unspecified", 4.199, at)
        self.assertIn("2026-10-26", next(iter(self.ledger.days.values())))
        self.assertEqual(len(self.ledger.feed()["stations"]), 1)

    def test_dst_calendar_day_is_not_fixed_24_hours(self):
        self.ledger.now = datetime(2026, 11, 1, 17, tzinfo=timezone.utc)
        self.ledger.observe(self.station, "UL:1", "REGULAR_UNLEADED", "posted_unspecified", 4.199, self.ledger.now)
        old = self.ledger.now
        self.ledger.now = datetime(2026, 10, 31, 16, tzinfo=timezone.utc)
        self.ledger.observe(self.station, "UL:1", "REGULAR_UNLEADED", "posted_unspecified", 4.299, self.ledger.now)
        self.ledger.now = old
        self.assertEqual(self.ledger.feed()["stations"][0]["quotes"][0]["day"]["price_mills"], 4299)

    def test_stale_and_previous_local_day_are_hidden(self):
        self.add(4.199)
        self.ledger.now += timedelta(hours=13)
        self.assertEqual(self.ledger.feed()["stations"], [])

    def test_conflicting_identical_timestamp_is_rejected(self):
        self.add(4.199)
        with self.assertRaises(ValueError): self.add(4.299)

    def test_no_google_or_driver_input_path(self):
        for source in ["google:1", "driver:1", "manual:1"]:
            with self.assertRaises(ValueError): self.add(4.199, station={"id": source})

    def test_invalid_values_and_future_times_are_rejected(self):
        for value in [0, -1, "NaN", "Infinity", "1.1234", 100]:
            with self.assertRaises((ValueError, ArithmeticError)): mills(value)
        with self.assertRaises(ValueError):
            self.ledger.observe(self.station, "UL", "REGULAR_UNLEADED", "posted_unspecified", 4.199, self.now+timedelta(seconds=1))

    def test_literal_parser_does_not_execute_javascript(self):
        self.assertEqual(literal('data:{fuelPrices:[{price:.999,name:"x:y"}]}', 'data:{fuelPrices:['), [{"price":.999,"name":"x:y"}])
        for text in ['data:{fuelPrices:[alert(1)]}', 'data:{fuelPrices:[{x:process.exit()}]}', 'data:{fuelPrices:[{x:undefined}]}']:
            with self.assertRaises(ValueError): literal(text, 'data:{fuelPrices:[')

    def test_grades_do_not_mislabel_e15_as_regular(self):
        self.assertEqual(kwik_grade("UNLEADED 87 (10% ETH)"), "REGULAR_UNLEADED")
        self.assertEqual(kwik_grade("DIESEL #2"), "DIESEL")
        for label in ["UNLEADED 88 (15% ETH)", "E85", "OFF ROAD DIESEL", "DIESEL #1"]:
            self.assertIsNone(kwik_grade(label))

    def test_saved_live_pilot_page_identity_and_product_codes(self):
        fixture = Path(__file__).resolve().parent/"fixtures/pilot-location.html"
        if not fixture.exists(): self.fail("Retailer schema fixture missing")
        station, fuels = pilot_location(fixture.read_text(encoding="utf-8"), "705")
        self.assertEqual(station["state"], "OK")
        self.assertTrue(any(f["name"] == "E15" for f in fuels))
        with self.assertRaises(ValueError): pilot_location(fixture.read_text(encoding="utf-8"), "999")

    def test_direct_costco_prices_use_actual_fetch_time_and_same_history_product(self):
        meta={"station_key":"US-COSTCO-1", "source_station_id":"1", "brand":"COSTCO", "country":"US", "status":"active", "region":"WI", "name":"Town", "address":"100 Main St", "city":"Town", "postcode":"54301", "lat":44.5, "lon":-88.0}
        old=self.now;self.ledger.now=self.now-timedelta(days=1)
        station=self.station | {"id":"club:US-COSTCO-1"}
        self.ledger.observe(station,"costco-us-gasprices:regular","REGULAR_UNLEADED","posted_unspecified",4.299,self.ledger.now)
        self.ledger.now=old
        count=import_costco_current(self.ledger,{"1":meta},{"1":{"regular":"4.199"}},self.now,lambda **_:"America/Chicago")
        self.assertEqual(count,1)
        quote=self.ledger.feed()["stations"][0]["quotes"][0]
        self.assertEqual(quote["day"]["price_mills"],4299)
        self.assertEqual(quote["current"]["at"],int(self.now.timestamp()))

    def test_costco_puerto_rico_litres_and_closed_stations_are_excluded(self):
        meta={"station_key":"US-COSTCO-1", "source_station_id":"1", "brand":"COSTCO", "country":"US", "status":"active", "region":"PR"}
        self.assertEqual(import_costco_current(self.ledger,{"1":meta},{"1":{"regular":"1.099"}},self.now,lambda **_:"America/Puerto_Rico"),0)
        meta=meta | {"region":"WI","status":"closed"}
        self.assertEqual(import_costco_current(self.ledger,{"1":meta},{"1":{"regular":"4.199"}},self.now,lambda **_:"America/Chicago"),0)

    def test_costco_batch_protocol_and_ten_store_limit(self):
        self.assertTrue(costco_batch_url(["1162","1"]).endswith("warehouseid=1162_1"))
        for ids in [[],["1"]*11,["1162,1"],["../1"]]:
            with self.assertRaises(ValueError): costco_batch_url(ids)

    def circlek(self):
        return json.loads((Path(__file__).resolve().parent/"fixtures/circlek-station.json").read_text(encoding="utf-8"))

    def import_circlek_fixture(self, rows):
        return import_circlek(self.ledger, rows, self.ledger.now, lambda **_: "America/New_York")

    def test_circlek_real_schema_retains_update_and_rejects_old_and_unknown_grades(self):
        result = self.import_circlek_fixture([self.circlek()])
        self.assertEqual(result["accepted_stations"], 1)
        self.assertEqual(result["accepted_quotes"], 1)
        q = self.ledger.feed()["stations"][0]["quotes"][0]
        self.assertEqual(q["product"], "circlek:UNL")
        self.assertEqual(q["grade"], "REGULAR_UNLEADED")
        self.assertEqual(q["current"]["price_mills"], 4699)
        self.assertEqual(q["current"]["retailer_updated_raw"], "2026-10-26 07:55:00.0")
        self.assertEqual(q["current"]["at"], int(self.now.timestamp()))

    def test_circlek_observations_accumulate_actual_day_and_week_without_backfill(self):
        fixture = self.circlek()
        for days, price in [(7,4.199),(1,4.499),(0,4.699)]:
            self.ledger.now = self.now-timedelta(days=days)
            row = copy.deepcopy(fixture)
            row["fuelPrices"] = [{"code":"UNL", "price":price, "currency":"usd", "volumeUnit":"gallon", "lastUpdated":self.ledger.now.strftime("%Y-%m-%d 07:55:00.0")}]
            self.import_circlek_fixture([row])
        q = self.ledger.feed()["stations"][0]["quotes"][0]
        self.assertEqual(q["day"]["price_mills"], 4499)
        self.assertEqual(q["week"]["price_mills"], 4199)
        self.ledger.save()
        self.assertEqual(Ledger(self.ledger.path,self.now).feed(),self.ledger.feed())

    def test_circlek_old_missing_future_or_invalid_update_does_not_become_today(self):
        for label in [None,"", "invalid", "2026-10-25 23:59:00.0", "2026-10-27 00:00:00.0", "2026-10-26T16:00:01Z", "2026-10-25T16:00:00Z"]:
            self.assertFalse(circlek_quote_is_current(label,self.now,"America/New_York"),label)
        self.assertTrue(circlek_quote_is_current("2026-10-26T15:00:00Z",self.now,"America/New_York"))
        self.assertTrue(circlek_quote_is_current("2026-10-26 07:55:00.0",self.now,"America/New_York"))

    def test_circlek_station_local_date_and_dst_are_not_assumed_utc(self):
        at = datetime(2026,10,27,1,tzinfo=timezone.utc)
        self.assertTrue(circlek_quote_is_current("2026-10-26 12:00:00.0",at,"America/Chicago"))
        self.assertFalse(circlek_quote_is_current("2026-10-27 12:00:00.0",at,"America/Chicago"))
        at = datetime(2026,11,1,17,tzinfo=timezone.utc)
        self.assertTrue(circlek_quote_is_current("2026-11-01 09:00:00.0",at,"America/New_York"))

    def test_circlek_duplicate_identity_or_product_never_picks_a_cheaper_value(self):
        row = self.circlek()
        self.assertEqual(self.import_circlek_fixture([row,copy.deepcopy(row)])["accepted_quotes"],0)
        row["fuelPrices"].append(next(copy.deepcopy(q) for q in row["fuelPrices"] if q["code"]=="UNL"))
        self.assertEqual(self.import_circlek_fixture([row])["accepted_quotes"],0)

    def test_circlek_region_country_brand_currency_and_units_are_required(self):
        rows=[]
        for changed in [{"latitude":43.0},{"publicBrand":"OTHER"},{"longitude":-79.0}]:
            rows.append(self.circlek()|changed)
        wrong_country=self.circlek();wrong_country["address"]["country"]="CA";rows.append(wrong_country)
        for key,value in [("currency","cad"),("volumeUnit","litre"),("code","E15"),("code","PNA")]:
            row=self.circlek();row["fuelPrices"]=[{"code":"UNL","price":4.699,"currency":"usd","volumeUnit":"gallon","lastUpdated":"2026-10-26 07:55:00.0"}|{key:value}];rows.append(row)
        for row in rows:
            self.assertEqual(self.import_circlek_fixture([row])["accepted_quotes"],0)

    def test_circlek_bounded_region_wont_silently_truncate(self):
        with self.assertRaises(ValueError):self.import_circlek_fixture([self.circlek()]*100)
        with self.assertRaises(ValueError):self.import_circlek_fixture({"stations":[]})
        self.assertIn("maxResults=100",circlek_up_url())
        self.assertIn("country=US",circlek_up_url())

    def test_public_reader_handles_gzip_and_caps_decompressed_bytes(self):
        class Response(io.BytesIO):
            headers={"Content-Encoding":"gzip"}
            def geturl(self):return circlek_up_url()
        with patch("collect.urlopen",return_value=Response(gzip.compress(b"[]"))):
            self.assertEqual(PublicReader().get(circlek_up_url(),100),b"[]")
        with patch("collect.urlopen",return_value=Response(gzip.compress(b"x"*5000))):
            with self.assertRaisesRegex(ValueError,"Decompressed"):
                PublicReader().get(circlek_up_url(),100)

    def test_public_reader_keeps_downloaded_gzip_files_compressed(self):
        class Response(io.BytesIO):
            headers={"Content-Type":"application/gzip"}
            def geturl(self):return "https://github.com/coatless-data/club-gas-prices/releases/download/data/history.csv.gz"
        raw=gzip.compress(b"archived retailer observations")
        with patch("collect.urlopen",return_value=Response(raw)):
            self.assertEqual(PublicReader().get(Response().geturl()),raw)


if __name__ == "__main__":
    unittest.main()
