"""Automatic retailer observations for TravIR. Never accepts Google or driver prices.

Run on a server, separately from map rendering. Public posted prices are facts
observed on a website, not a guarantee of the current pump price. Source names,
original product labels and collection times accompany every comparison.
"""
from __future__ import annotations

import argparse
import csv
import gzip
import hashlib
import html as html_module
import io
import json
import math
import re
import time
from collections import Counter, defaultdict
from datetime import datetime, timedelta, timezone
from decimal import Decimal, InvalidOperation
from pathlib import Path
from urllib.parse import urlencode, urlparse
from urllib.error import HTTPError
from urllib.request import Request, urlopen
from zoneinfo import ZoneInfo

ALLOWED = {"www.kwiktrip.com", "pilotcompany.com", "www.pilotcompany.com",
           "api.github.com", "github.com", "objects.githubusercontent.com",
           "release-assets.githubusercontent.com"}
MAX_AGE = 12 * 3600
GRADES = {"regular": "REGULAR_UNLEADED", "premium": "PREMIUM", "diesel": "DIESEL"}


def utc(value: str) -> datetime:
    at = datetime.fromisoformat(value.replace("Z", "+00:00"))
    if at.tzinfo is None:
        raise ValueError("Missing timestamp timezone")
    return at.astimezone(timezone.utc)


def mills(value) -> int:
    price = Decimal(str(value))
    if not price.is_finite() or not Decimal("0.1") <= price <= Decimal("20"):
        raise ValueError("Invalid USD/gal price")
    scaled = price * 1000
    if scaled != scaled.to_integral_value():
        raise ValueError("Invalid price precision")
    return int(scaled)


class PublicReader:
    def __init__(self):
        self.last: dict[str, float] = {}

    def get(self, url: str, limit: int = 8_000_000) -> bytes:
        parsed = urlparse(url)
        if parsed.scheme != "https" or parsed.hostname not in ALLOWED or parsed.username:
            raise ValueError("Unapproved public source")
        wait = 1.05 - (time.monotonic() - self.last.get(parsed.hostname, 0))
        if wait > 0:
            time.sleep(wait)
        self.last[parsed.hostname] = time.monotonic()
        with urlopen(Request(url, headers={"User-Agent": "TravIR-retailer-history/1.0"}), timeout=35) as response:
            if urlparse(response.geturl()).hostname not in ALLOWED:
                raise ValueError("Unexpected redirect")
            data = response.read(limit + 1)
        if len(data) > limit:
            raise ValueError("Response exceeds collection budget")
        return data


def literal(html: str, marker: str, *, unique: bool = True):
    """Parse a literal object/array in a published page; never evaluate JavaScript."""
    if marker not in html or (unique and html.count(marker) != 1):
        raise ValueError("Retailer page format changed")
    begin = html.index(marker) + len(marker) - 1
    if html[begin] not in "[{":
        raise ValueError("Expected literal")
    quoted = escaped = False
    stack = []
    end = None
    for position in range(begin, min(len(html), begin + 4_000_000)):
        char = html[position]
        if quoted:
            if escaped:
                escaped = False
            elif char == "\\":
                escaped = True
            elif char == '"':
                quoted = False
        elif char == '"':
            quoted = True
        elif char in "[{":
            stack.append(char)
        elif char in "]}":
            if not stack or stack.pop() != ("]" == char and "[" or "{"):
                raise ValueError("Unbalanced literal")
            if not stack:
                end = position + 1
                break
    if end is None:
        raise ValueError("Incomplete retailer literal")
    parts = re.split(r'("(?:\\.|[^"\\])*")', html[begin:end])
    for index in range(0, len(parts), 2):
        parts[index] = re.sub(r'([{,])\s*([A-Za-z_$][\w$]*):', r'\1"\2":', parts[index])
        parts[index] = re.sub(r'([:\[,])(-?)\.(\d+)', r'\g<1>\g<2>0.\3', parts[index])
    return json.loads("".join(parts))


class Ledger:
    def __init__(self, path: Path, now: datetime):
        self.path, self.now = path, now.astimezone(timezone.utc)
        self.stations: dict[str, dict] = {}
        self.days: dict[str, dict] = {}
        if path.exists():
            saved = json.loads(path.read_text(encoding="utf-8"))
            if saved.get("schema_version") != 1:
                raise ValueError("Unknown history state version")
            self.stations = saved["stations"]
            self.days = saved["days"]

    def observe(self, station: dict, product: str, grade: str, basis: str, price,
                at: datetime, *, price_is_mills: bool = False):
        if not station["id"].startswith(("kwiktrip:", "pilot:", "club:")):
            raise ValueError("Only automatic retailer adapters are accepted")
        if grade not in set(GRADES.values()) | {"MIDGRADE"} or not product.strip():
            raise ValueError("Unsupported product")
        if basis not in {"posted_unspecified", "cash", "credit", "member"}:
            raise ValueError("Unknown price basis")
        if at.tzinfo is None:
            raise ValueError("Missing observation timezone")
        at = at.astimezone(timezone.utc)
        if not 0 <= (self.now-at).total_seconds() <= MAX_AGE:
            raise ValueError("Stale or future observation")
        lat, lon = station["lat"], station["lon"]
        if not (math.isfinite(lat) and math.isfinite(lon) and 18 <= lat <= 72 and -180 <= lon <= -65):
            raise ValueError("Invalid US coordinates")
        if any(not isinstance(station.get(key), str) or not station[key].strip()
               for key in ("name", "address", "city", "state", "postcode", "timezone", "source", "source_url")):
            raise ValueError("Incomplete station identity")
        zone = ZoneInfo(station["timezone"])
        amount = int(price) if price_is_mills else mills(price)
        if not 100 <= amount <= 20000:
            raise ValueError("Invalid price")
        # A source/product/basis is never compared with another provider or blend.
        key = json.dumps([station["id"], product, grade, basis], separators=(",", ":"))
        day = at.astimezone(zone).date().isoformat()
        row = {"at": int(at.timestamp()), "price_mills": amount}
        prior = self.days.setdefault(key, {}).get(day)
        if prior and prior["at"] == row["at"] and prior["price_mills"] != amount:
            raise ValueError("Conflicting observations at the same instant")
        if not prior or prior["at"] < row["at"]:
            self.days[key][day] = row
        self.stations[station["id"]] = station

    def feed(self) -> dict:
        grouped = defaultdict(list)
        for key, days in self.days.items():
            station_id, product, grade, basis = json.loads(key)
            station = self.stations.get(station_id)
            if not station or not days:
                continue
            zone = ZoneInfo(station["timezone"])
            today = self.now.astimezone(zone).date()
            current = days.get(today.isoformat())
            if not current or not 0 <= self.now.timestamp()-current["at"] <= MAX_AGE:
                continue
            quote = {"product": product, "grade": grade, "basis": basis, "current": current}
            for name, count in [("day", 1), ("week", 7)]:
                old = days.get((today-timedelta(days=count)).isoformat())
                if old and old["at"] < current["at"]:
                    quote[name] = old
            grouped[station_id].append(quote)
        stations = []
        for station_id, quotes in sorted(grouped.items()):
            counts = Counter(q["grade"] for q in quotes)
            # Two blends for a selected grade are ambiguous. Do not pick the cheaper one.
            quotes = [q for q in quotes if counts[q["grade"]] == 1]
            if quotes:
                stations.append(self.stations[station_id] | {"quotes": sorted(quotes, key=lambda q:q["grade"])})
        return {"schema_version": 1, "generated_at": int(self.now.timestamp()),
                "currency": "USD", "unit": "US_GALLON", "stations": stations}

    def save(self):
        cutoff = (self.now-timedelta(days=10)).date().isoformat()
        self.days = {key: {day: row for day, row in values.items() if day >= cutoff}
                     for key, values in self.days.items()}
        self.days = {key: values for key, values in self.days.items() if values}
        used = {json.loads(key)[0] for key in self.days}
        self.stations = {key: value for key, value in self.stations.items() if key in used}
        self.path.parent.mkdir(parents=True, exist_ok=True)
        atomic_json(self.path, {"schema_version": 1, "stations": self.stations, "days": self.days})


def atomic_json(path: Path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix+".tmp")
    temporary.write_text(json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))+"\n", encoding="utf-8")
    temporary.replace(path)


def kwik_grade(label: str) -> str | None:
    text = label.upper()
    if text in {"UNLEADED 87 (10% ETH)", "UNLEADED 87", "UNLEADED 87 (NO ETH)"}:
        return "REGULAR_UNLEADED"
    if text.startswith("PREMIUM 91") or text.startswith("PREMIUM 93"):
        return "PREMIUM"
    if text == "DIESEL #2":
        return "DIESEL"
    return None  # E15, E85, winter blends and off-road fuel are not regular gasoline.


def collect_kwik(reader: PublicReader, ledger: Ledger, zone_lookup, selected_ids: set[str] | None):
    catalog = json.loads(reader.get("https://www.kwiktrip.com/storelistproxy.php"))["stores"]
    ids = sorted({str(s["id"]) for s in catalog}, key=int)
    if selected_ids is not None:
        ids = [value for value in ids if value in selected_ids]
    imported = 0
    for begin in range(0, len(ids), 10):
        url = "https://www.kwiktrip.com/storeinformationsproxy.php?"+urlencode({"ids": ",".join(ids[begin:begin+10])})
        payload = json.loads(reader.get(url)); at = datetime.now(timezone.utc)
        ledger.now = at
        for store in payload["stores"]:
            a = store.get("address") or {}
            zone = zone_lookup(lng=a["longitude"], lat=a["latitude"])
            if not zone:
                continue
            station = {"id": "kwiktrip:"+str(store["storeNumber"]), "name": store["name"],
                       "address": a["address1"], "city": a["city"], "state": a["state"], "postcode": str(a["zip"]),
                       "lat": a["latitude"], "lon": a["longitude"], "timezone": zone,
                       "source": "Kwik Trip / Kwik Star posted prices", "source_url": "https://www.kwiktrip.com/locator"}
            for fuel in store.get("fuel") or []:
                grade = kwik_grade(fuel.get("type", ""))
                if grade:
                    try:
                        ledger.observe(station, fuel["type"], grade, "posted_unspecified", fuel["currentPrice"], at)
                        imported += 1
                    except (ValueError, InvalidOperation, TypeError):
                        pass
        if begin % 100 == 0:
            ledger.save()
            print(f"Kwik Trip/Kwik Star: {min(begin+10,len(ids))}/{len(ids)} public stores", flush=True)
    return imported


def pilot_location(page: str, station_id: str) -> tuple[dict, list[dict]]:
    candidates = []
    for text in re.findall(r'<script[^>]*type="application/ld\+json"[^>]*>(.*?)</script>', page, re.S):
        try:
            value = json.loads(html_module.unescape(text))
            candidates.extend(value if isinstance(value, list) else value.get("@graph", [value]))
        except (ValueError, AttributeError):
            continue
    value = next((item for item in candidates if item.get("@type") == "GasStation"), None)
    if not value or str(value.get("url", "")).rstrip("/") != "https://pilotcompany.com/locations/"+station_id:
        raise ValueError("Pilot station identity missing or changed")
    address, geo = value["address"], value["geo"]
    if address.get("addressCountry") not in ("US", "United States"):
        raise ValueError("Not a US station")
    station = {"id": "pilot:"+station_id, "name": value["name"], "address": address["streetAddress"],
               "city": address["addressLocality"], "state": address["addressRegion"],
               "postcode": address["postalCode"], "lat": float(geo["latitude"]), "lon": float(geo["longitude"]),
               "source": "Pilot / Flying J network posted prices", "source_url": value["url"]}
    fuels = literal(page, "fuelPrices:[", unique=False)
    if not isinstance(fuels, list) or len(fuels) > 40 or not all(isinstance(f, dict) and "fuelDescription" in f for f in fuels):
        raise ValueError("Pilot fuel schema changed")
    return station, fuels


def collect_pilot(reader: PublicReader, ledger: Ledger, zone_lookup, limit: int | None):
    records = literal(reader.get("https://pilotcompany.com/fuel-prices").decode(), "data:{fuelPrices:[")
    ids = sorted({r["locationId"] for r in records if r.get("country") == "United States" and r.get("currency") == "USD" and str(r.get("locationId", "")).isdigit()}, key=int)
    if limit is not None:
        ids = ids[:limit]
    imported = failed = 0
    grade_map = {"UL": "REGULAR_UNLEADED", "UNL": "REGULAR_UNLEADED", "SUP": "PREMIUM", "MID": "MIDGRADE", "DSL": "DIESEL"}
    for index, station_id in enumerate(ids):
        try:
            page = reader.get("https://pilotcompany.com/locations/"+station_id).decode()
            at = datetime.now(timezone.utc)
            ledger.now = at
            station, fuels = pilot_location(page, station_id)
            station["timezone"] = zone_lookup(lng=station["lon"], lat=station["lat"])
            if not station["timezone"]:
                raise ValueError("Unknown timezone")
            counts = Counter(f.get("name") for f in fuels)
            for fuel in fuels:
                name = fuel.get("name")
                grade = grade_map.get(name)
                if not grade or counts[name] != 1:
                    continue
                try:
                    cash, credit = mills(fuel["cashPrice"]), mills(fuel["creditPrice"])
                    # Google's displayed basis is unspecified. Hide a trend when a
                    # station has different cash/credit prices instead of guessing.
                    if cash != credit:
                        continue
                    product = str(name)+":"+str(fuel["fuelCode"])
                    ledger.observe(station, product, grade, "posted_unspecified", cash, at, price_is_mills=True)
                    imported += 1
                except (KeyError, ValueError, InvalidOperation, TypeError):
                    continue
        except Exception as error:
            failed += 1
            print(f"Pilot public station {station_id} unavailable ({type(error).__name__}); history stays hidden", flush=True)
            if isinstance(error, HTTPError) and error.code in (403, 429):
                ledger.save()
                raise ValueError("Retailer denied or rate-limited collection; no bypass attempted") from None
        if index % 50 == 0:
            ledger.save()
            print(f"Pilot network: {index+1}/{len(ids)} public stores", flush=True)
    if not imported:
        raise ValueError("No valid Pilot prices collected")
    return {"quotes": imported, "unavailable_stations": failed}


def collect_clubs(reader: PublicReader, ledger: Ledger):
    release = json.loads(reader.get("https://api.github.com/repos/coatless-data/club-gas-prices/releases/tags/current"))
    assets = {a["name"]: a for a in release["assets"]}
    manifest = json.loads(reader.get(assets["manifest.json"]["browser_download_url"]))
    files = {}
    for name in ("site-stations.json", "site-latest.json", "club-gas-all.csv.gz"):
        raw = reader.get(assets[name]["browser_download_url"], limit=16_000_000)
        digest = hashlib.sha256(raw).hexdigest()
        if digest != manifest["assets"][name]["sha256"] or assets[name].get("digest") not in (None, "sha256:"+digest):
            raise ValueError("Club release changed during download; no mixed capture accepted")
        files[name] = raw
    metadata = {s["station_key"]: s for s in json.loads(files["site-stations.json"]) if s["country"] == "US" and s["status"] == "active" and not s.get("superseded_by")}
    wanted = {s["station_key"] for s in json.loads(files["site-latest.json"]) if s["country"] == "US" and s["status"] == "active"}
    # Only the last eight local days are needed. Stream the gzip rather than inflate
    # an unbounded file in RAM. The ZIP is never installed or executed.
    imported = scanned = 0
    with gzip.GzipFile(fileobj=io.BytesIO(files["club-gas-all.csv.gz"])) as compressed:
        with io.TextIOWrapper(compressed, encoding="utf-8", newline="") as text:
            def bounded_lines():
                total = 0
                while line := text.readline(32001):
                    total += len(line)
                    if len(line)>32000 or total>256_000_000:
                        raise ValueError("Club history exceeds decompression budget")
                    yield line
            for row in csv.DictReader(bounded_lines()):
                scanned += 1
                if scanned > 2_000_000:
                    raise ValueError("Club history exceeds processing budget")
                sid = row["station_key"]
                grade = GRADES.get(row["grade"])
                if sid not in wanted or sid not in metadata or not grade or row["currency"] != "USD" or row["price_unit"] != "USD/gal":
                    continue
                at = utc(row["captured_at_utc"])
                if not 0 <= (ledger.now-at).total_seconds() <= 9*86400:
                    continue
                meta = metadata[sid]
                station = {"id": "club:"+sid, "name": meta["name"], "address": meta["address"],
                           "city": meta["city"], "state": meta["region"], "postcode": meta["postcode"],
                           "lat": meta["lat"], "lon": meta["lon"], "timezone": row["timezone"],
                           "source": ("Costco" if meta["brand"] == "COSTCO" else "Sam's Club")+" posted prices · Club Gas Prices",
                           "source_url": "https://github.com/coatless-data/club-gas-prices"}
                # Import the publisher's dated automatic retailer observations.
                # Do not retimestamp old data as today or turn missing days into Same.
                saved_now = ledger.now
                try:
                    ledger.now = at
                    ledger.observe(station, row["source"]+":"+row["grade_raw"], grade, "posted_unspecified", row["price"], at)
                    imported += 1
                except (ValueError, InvalidOperation, TypeError):
                    continue
                finally:
                    ledger.now = saved_now
    return imported


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--state", type=Path, default=Path("state/retailer-history.json"))
    parser.add_argument("--output", type=Path, default=Path("public/fuel-history.json"))
    parser.add_argument("--kwik-ids", help="Optional evaluation subset, comma-separated")
    parser.add_argument("--pilot-limit", type=int, help="Optional evaluation station limit")
    parser.add_argument("--providers", default="clubs,kwiktrip,pilot")
    args = parser.parse_args()
    from timezonefinder import TimezoneFinder
    now = datetime.now(timezone.utc)
    ledger, reader = Ledger(args.state, now), PublicReader()
    report = {"started_at": now.isoformat(), "providers": {}, "driver_reports": False, "google_prices_archived": False}
    with TimezoneFinder(in_memory=True) as finder:
        for provider in args.providers.split(","):
            ledger.now = datetime.now(timezone.utc)
            try:
                if provider == "clubs":
                    result = collect_clubs(reader, ledger)
                elif provider == "kwiktrip":
                    selected = set(args.kwik_ids.split(",")) if args.kwik_ids else None
                    result = collect_kwik(reader, ledger, finder.timezone_at, selected)
                elif provider == "pilot":
                    result = collect_pilot(reader, ledger, finder.timezone_at, args.pilot_limit)
                else:
                    raise ValueError("Unknown automatic provider")
                report["providers"][provider] = {"ok": True, "result": result}
            except Exception as error:
                report["providers"][provider] = {"ok": False, "error": type(error).__name__}
                print(f"{provider} unavailable ({type(error).__name__}); preserving previous observations", flush=True)
            ledger.now = datetime.now(timezone.utc)
            ledger.save()
    ledger.now = datetime.now(timezone.utc)
    feed = ledger.feed()
    if not feed["stations"]:
        raise SystemExit("No fresh automatic station data; existing published feed was not overwritten")
    encoded = json.dumps(feed, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode()
    if len(encoded) > 4_000_000 or len(feed["stations"]) > 10000:
        raise SystemExit("Feed exceeds the app's bounded download budget")
    atomic_json(args.output, feed)
    report.update(finished_at=ledger.now.isoformat(), stations=len(feed["stations"]), feed_sha256=hashlib.sha256(args.output.read_bytes()).hexdigest(), feed_bytes=args.output.stat().st_size,
                  day_comparisons=sum("day" in q for s in feed["stations"] for q in s["quotes"]),
                  week_comparisons=sum("week" in q for s in feed["stations"] for q in s["quotes"]))
    atomic_json(args.output.with_name("collection-status.json"), report)
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
